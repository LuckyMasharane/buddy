// @flow
import createFieldArray from '../createFieldArray'
import immutable from '../structure/immutable'

export default createFieldArray(immutable)
