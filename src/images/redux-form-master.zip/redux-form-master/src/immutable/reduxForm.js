// @flow
import createReduxForm from '../createReduxForm'
import immutable from '../structure/immutable'

export default createReduxForm(immutable)
