# Does `redux-form` work with React Native?
  
Yes, it does!  
Most of Redux Form will work just fine.

However, there are some minor differences very well detailed by [@esbenp](https://github.com/esbenp)
in his blog post [**Simple React Native forms with redux-form, immutable.js and styled-components**](http://esbenp.github.io/2017/01/06/react-native-redux-form-immutable-styled-components/).  
We highly recommend you to follow it.
