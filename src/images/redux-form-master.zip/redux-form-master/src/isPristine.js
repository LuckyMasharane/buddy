// @flow
import createIsPristine from './selectors/isPristine'
import plain from './structure/plain'

export default createIsPristine(plain)
