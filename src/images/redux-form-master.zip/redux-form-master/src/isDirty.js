// @flow
import createIsDirty from './selectors/isDirty'
import plain from './structure/plain'

export default createIsDirty(plain)
