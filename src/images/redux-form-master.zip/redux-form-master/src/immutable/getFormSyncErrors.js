// @flow
import createGetFormSyncErrors from '../selectors/getFormSyncErrors'
import immutable from '../structure/immutable'

export default createGetFormSyncErrors(immutable)
