// @flow
import createGetFormNames from './selectors/getFormNames'
import plain from './structure/plain'

export default createGetFormNames(plain)
