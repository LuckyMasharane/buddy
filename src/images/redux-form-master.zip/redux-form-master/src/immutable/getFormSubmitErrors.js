// @flow
import createGetFormSubmitErrors from '../selectors/getFormSubmitErrors'
import immutable from '../structure/immutable'

export default createGetFormSubmitErrors(immutable)
