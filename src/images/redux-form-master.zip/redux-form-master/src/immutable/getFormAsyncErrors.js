// @flow
import createGetFormAsyncErrors from '../selectors/getFormAsyncErrors'
import immutable from '../structure/immutable'

export default createGetFormAsyncErrors(immutable)
