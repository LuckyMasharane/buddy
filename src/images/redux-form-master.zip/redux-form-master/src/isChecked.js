// @flow
const isChecked = (value: any) => {
  if (typeof value === 'boolean') {
    return value
  }
  if (typeof value === 'string') {
    const lower = value.toLowerCase()
    if (lower === 'true') {
      return true
    }
    if (lower === 'false') {
      return false
    }
  }
  return undefined
}

export default isChecked
