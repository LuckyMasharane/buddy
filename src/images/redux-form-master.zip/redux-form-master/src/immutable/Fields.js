// @flow
import createFields from '../createFields'
import immutable from '../structure/immutable'

export default createFields(immutable)
