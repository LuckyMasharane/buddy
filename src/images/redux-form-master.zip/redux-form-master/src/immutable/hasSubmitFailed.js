// @flow
import createHasSubmitFailed from '../selectors/hasSubmitFailed'
import immutable from '../structure/immutable'

export default createHasSubmitFailed(immutable)
