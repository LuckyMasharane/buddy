// @flow
import createFormValueSelector from './createFormValueSelector'
import plain from './structure/plain'

export default createFormValueSelector(plain)
