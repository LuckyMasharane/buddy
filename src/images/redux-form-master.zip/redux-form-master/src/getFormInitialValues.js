// @flow
import createGetFormInitialValues from './selectors/getFormInitialValues'
import plain from './structure/plain'

export default createGetFormInitialValues(plain)
