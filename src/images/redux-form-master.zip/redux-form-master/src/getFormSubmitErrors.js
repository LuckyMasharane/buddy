// @flow
import createGetFormSubmitErrors from './selectors/getFormSubmitErrors'
import plain from './structure/plain'

export default createGetFormSubmitErrors(plain)
