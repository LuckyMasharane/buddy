# Synchronous Validation Example

## To run locally

```
npm install
npm start
```

Then open [`http://localhost:3030/`](http://localhost:3030/).
