// @flow
export const dataKey = 'text'
