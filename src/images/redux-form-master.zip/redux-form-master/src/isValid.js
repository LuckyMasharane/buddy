// @flow
import createIsValid from './selectors/isValid'
import plain from './structure/plain'

export default createIsValid(plain)
