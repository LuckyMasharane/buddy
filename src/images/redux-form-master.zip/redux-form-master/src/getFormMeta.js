// @flow
import createGetFormMeta from './selectors/getFormMeta'
import plain from './structure/plain'

export default createGetFormMeta(plain)
