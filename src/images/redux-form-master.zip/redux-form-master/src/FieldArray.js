// @flow
import createFieldArray from './createFieldArray'
import plain from './structure/plain'

export default createFieldArray(plain)
