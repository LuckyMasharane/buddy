// @flow
import createIsInvalid from '../selectors/isInvalid'
import immutable from '../structure/immutable'

export default createIsInvalid(immutable)
