// @flow
import createGetFormError from '../selectors/getFormError'
import immutable from '../structure/immutable'

export default createGetFormError(immutable)
