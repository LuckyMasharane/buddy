// @flow
import createGetFormSyncWarnings from '../selectors/getFormSyncWarnings'
import immutable from '../structure/immutable'

export default createGetFormSyncWarnings(immutable)
