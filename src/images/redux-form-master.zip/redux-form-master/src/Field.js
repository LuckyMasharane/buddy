// @flow
import createField from './createField'
import plain from './structure/plain'

export default createField(plain)
