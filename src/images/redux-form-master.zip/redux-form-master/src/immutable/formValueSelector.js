// @flow
import createFormValueSelector from '../createFormValueSelector'
import immutable from '../structure/immutable'

export default createFormValueSelector(immutable)
