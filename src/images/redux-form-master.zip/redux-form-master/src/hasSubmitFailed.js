// @flow
import createHasSubmitFailed from './selectors/hasSubmitFailed'
import plain from './structure/plain'

export default createHasSubmitFailed(plain)
