// @flow
import createReducer from '../createReducer'
import immutable from '../structure/immutable'

export default createReducer(immutable)
